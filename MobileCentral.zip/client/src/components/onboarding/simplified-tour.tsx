import React from "react";

export function OnboardingTour() {
  return null;
}